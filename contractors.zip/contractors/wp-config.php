<?php
/**
 * The base configuration for WordPress
 *
 * The wp-config.php creation script uses this file during the
 * installation. You don't have to use the web site, you can
 * copy this file to "wp-config.php" and fill in the values.
 *
 * This file contains the following configurations:
 *
 * * MySQL settings
 * * Secret keys
 * * Database table prefix
 * * ABSPATH
 *
 * @link https://codex.wordpress.org/Editing_wp-config.php
 *
 * @package WordPress
 */

// ** MySQL settings - You can get this info from your web host ** //
/** The name of the database for WordPress */
define( 'DB_NAME', 'contractors' );

/** MySQL database username */
define( 'DB_USER', 'root' );

/** MySQL database password */
define( 'DB_PASSWORD', '' );

/** MySQL hostname */
define( 'DB_HOST', 'localhost' );

/** Database Charset to use in creating database tables. */
define( 'DB_CHARSET', 'utf8mb4' );

/** The Database Collate type. Don't change this if in doubt. */
define( 'DB_COLLATE', '' );

/**#@+
 * Authentication Unique Keys and Salts.
 *
 * Change these to different unique phrases!
 * You can generate these using the {@link https://api.wordpress.org/secret-key/1.1/salt/ WordPress.org secret-key service}
 * You can change these at any point in time to invalidate all existing cookies. This will force all users to have to log in again.
 *
 * @since 2.6.0
 */
define( 'AUTH_KEY',         '2M?b<cC43,jVMq+CE.a5W@}.Uu*;D,kPnCcZQj~J5h&Q#5Xf6yndWGWGYa;W!~h&' );
define( 'SECURE_AUTH_KEY',  '7nX6Jb]|34<#@*;cMq`h {r}~kQ0&j..,#N$hd$Kn^GgW.Z,au4`^h{3!*W3pN5T' );
define( 'LOGGED_IN_KEY',    'V/1b#~dN&{Q`4bBAmVf7 g6+yKL?&li1Tu( mDaKP5qP3W>Lf*Q0Cte|QhYB6v^z' );
define( 'NONCE_KEY',        '>Q^%LE,aCJX?=p)NPD_|1W3tP7kgQ^86_[uF[+&cdc9ggyALzxLv,:z4bO){2pa:' );
define( 'AUTH_SALT',        'J*)ph&Ob0Jp1`ai01Y2C}_aX.7=Gvmza4A;,iJ<~pi1tULC$m8P8WO1oOn}j-bb.' );
define( 'SECURE_AUTH_SALT', '3^9W}7AO*6o[|2-*x3{pS+JQn8#9&E9X*bdzN(G> 9|`DDyUA@>GMg8JE4Jo9RD4' );
define( 'LOGGED_IN_SALT',   '}#/U=Cm=EK2k.1vLAtcGH6;?RX0Ncvq>yX+2XF[C :gz5o&lRIGw0>LKftL2#rk[' );
define( 'NONCE_SALT',       '04e4d!hwJsvNT:r/^@e.Mafj7D3Vu@F-R`1+$C7#g3nyo&dY(I3zsvY<5jPpz?EE' );

/**#@-*/

/**
 * WordPress Database Table prefix.
 *
 * You can have multiple installations in one database if you give each
 * a unique prefix. Only numbers, letters, and underscores please!
 */
$table_prefix = 'wp_';

/**
 * For developers: WordPress debugging mode.
 *
 * Change this to true to enable the display of notices during development.
 * It is strongly recommended that plugin and theme developers use WP_DEBUG
 * in their development environments.
 *
 * For information on other constants that can be used for debugging,
 * visit the Codex.
 *
 * @link https://codex.wordpress.org/Debugging_in_WordPress
 */
define( 'WP_DEBUG', false );

/* That's all, stop editing! Happy publishing. */

/** Absolute path to the WordPress directory. */
if ( ! defined( 'ABSPATH' ) ) {
	define( 'ABSPATH', dirname( __FILE__ ) . '/' );
}

/** Sets up WordPress vars and included files. */
require_once( ABSPATH . 'wp-settings.php' );
